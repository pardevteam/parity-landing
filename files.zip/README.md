# Parity

A single-screen terminal for tokenized equities and commodities on Solana — aggregating listings from issuers like xStocks, Dinari, Ondo, and Backed into one venue-agnostic view, with a companion utility token, **$PAR**.

This repo contains the landing page and an in-browser dashboard mockup, built as a single self-contained HTML file (no build step, no dependencies to install).

## What's in here

- **Landing page** — product pitch, why-now stats, a three-step "how it works," and an overview of $PAR's utility.
- **Dashboard mockup** — a working preview of the markets terminal: a live-look ticker tape, a markets table (price, 24h change, volume, sparkline) covering both equities (xTSLA, xNVDA, xAAPL, xSPY, xCOIN, xMSTR) and commodities (xGOLD, xWTI, xSLV), plus mock portfolio and rewards panels.

All market data shown is illustrative placeholder data, not a live feed.

## Running it locally

No build tools required — it's one HTML file.

```bash
git clone https://github.com/your-username/parity.git
cd parity
open parity.html   # or just double-click the file / drag it into a browser
```

## Deploying with GitHub Pages

1. Rename `parity.html` to `index.html` (or point Pages at `parity.html` directly).
2. In the repo, go to **Settings → Pages**, set the source to the `main` branch.
3. Your site will be live at `https://your-username.github.io/parity/`.

## Stack

Plain HTML, CSS, and vanilla JavaScript. Fonts loaded from Google Fonts (Inter for UI/headings, IBM Plex Mono for numeric/ticker data). No frameworks, no bundler.

## About $PAR

$PAR is designed as a **utility token**, not a security or a synthetic representation of any equity or commodity. It's meant to gate access to deeper market data (order-book depth, redemption-time tracking, custom alerts), enable governance over which issuers/instruments get listed, and reward users for keeping verified portfolio/liquidity data flowing through the platform.

It does **not** represent equity, a claim on any underlying company or commodity, or a promise of investment return. This repository is a design/product concept — nothing here is financial advice, and no token has been deployed.

## Disclaimer

Tokenized equity and commodity products carry issuer, custody, and smart-contract risk. Review each issuer's own disclosures before trading. This project is a concept preview.

## License

MIT — see `LICENSE` (add one if you plan to open-source this for real).
